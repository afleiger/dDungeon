﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chrisistheon
{

    public class Party
    {
        private A_Hero[] _party;
        public Party()
        {
            _party = new A_Hero[3];
        }

        public void AddHero(int i, A_Hero hero)
        {
            if (hero != null)
            {
                this._party[i] = hero;
            }
        }

        public override string ToString()
        {
            String word = _party[0].ClassName+"\n\n";
            word += _party[1].ClassName+"\n\n";
            word += _party[2].ClassName;
            return word;
        }
    }
}
