﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chrisistheon
{

    public class Party
    {
        private A_Hero[] _party;
        public Party()
        {
            _party = new A_Hero[3];
        }
    }
}
