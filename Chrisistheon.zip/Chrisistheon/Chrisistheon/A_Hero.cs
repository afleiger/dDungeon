﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chrisistheon
{
    public abstract class A_Hero : A_Entity
    {
        public int getPwr()
        {
            return 5;
        }

        public int getDefense()
        {
            return 20;
        }

        public int getSpeed()
        {
            return 10;
        }

        public abstract string GetName();

        public override string ToString()
        {
            return "Power: " + getPwr() + " Defense: " + getDefense() + " Speed: " + getSpeed();
        }
    }
}
