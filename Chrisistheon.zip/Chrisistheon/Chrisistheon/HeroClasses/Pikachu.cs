﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chrisistheon
{
    class Pikachu:A_Hero
    {
        public Pikachu(double hp, int pwr, int def, int spd) : base("Pikachu", hp, pwr, def, spd)
        {

        }

        public override string Attack()
        {
            return "";
        }
    }
}
