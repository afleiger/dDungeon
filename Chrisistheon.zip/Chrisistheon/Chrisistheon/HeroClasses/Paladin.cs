﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chrisistheon
{
    class Paladin: A_Hero
    {
        public Paladin(double hp, int pwr, int def, int spd) : base("Paladin", hp, pwr, def, spd)
        {

        }

        public override int Attack()
        {
            return -1;
        }
    }
}
