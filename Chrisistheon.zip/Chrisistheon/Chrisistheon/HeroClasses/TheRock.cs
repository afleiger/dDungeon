﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chrisistheon
{
    class TheRock:A_Hero
    {
        public TheRock(double hp, int pwr, int def, int spd) : base("The Rock", hp, pwr, def, spd)
        {

        }

        public override string Attack()
        {
            return "";
        }
    }
}
