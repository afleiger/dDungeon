﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chrisistheon
{
    class HeroFactory
    {
        public static A_Hero createHero(int index)
        {
            Database db = new Database();
            String className = db.getHeroName(index);
            int[] stats = db.getClassStats(className);
            return new Warrior(stats[0], stats[1], stats[2], stats[3]);
        }
        public static A_Hero createHero(String className)
        {
            Database db = new Database();
            int[] stats = db.getClassStats(className);

            if(className.Equals("Archer"))
                return new Archer(stats[0], stats[1], stats[2], stats[3]);
            if(className.Equals("Assassin"))
                return new Assassin(stats[0], stats[1], stats[2], stats[3]);
            if(className.Equals("Barbarian"))
                return new Barbarian(stats[0], stats[1], stats[2], stats[3]);
            if (className.Equals("Cleric"))
                return new Cleric(stats[0], stats[1], stats[2], stats[3]);
            if(className.Equals("Elementalist"))
                return new Elementalist(stats[0], stats[1], stats[2], stats[3]);
            if(className.Equals("Glass Cannon"))
                return new GlassCanon(stats[0], stats[1], stats[2], stats[3]);
            if (className.Equals("Guardian"))
                return new Guardian(stats[0], stats[1], stats[2], stats[3]);
            if (className.Equals("Mage"))
                return new Mage(stats[0], stats[1], stats[2], stats[3]);
            if(className.Equals("Paladin"))
                return new Paladin(stats[0], stats[1], stats[2], stats[3]);
            if (className.Equals("Pikachu")) 
                return new Pikachu(stats[0], stats[1], stats[2], stats[3]);
            if (className.Equals("Rogue"))
                return new Rogue(stats[0], stats[1], stats[2], stats[3]);
            if(className.Equals("Sanik"))
                return new Sanik(stats[0], stats[1], stats[2], stats[3]);
            if(className.Equals("Simba"))
                return new Simba(stats[0], stats[1], stats[2], stats[3]);
            if(className.Equals("The Rock"))
                return new TheRock(stats[0], stats[1], stats[2], stats[3]);
            if (className.Equals("Warrior"))
                return new Warrior(stats[0], stats[1], stats[2], stats[3]);
            if(className.Equals("Zombie"))
                return new Zombie(stats[0], stats[1], stats[2], stats[3]);

            return new NullClass(className,stats[0], stats[1], stats[2], stats[3]);
        }
    }
}
