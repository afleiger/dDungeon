﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chrisistheon
{
    class Zombie:A_Hero
    {
        public Zombie(double hp, int pwr, int def, int spd) : base("Zombie", hp, pwr, def, spd)
        {

        }

        public override string Attack()
        {
            return "";
        }

        public override double manipulateHealth(double hpChange)
        {
                curHP += hpChange;
                if (curHP > maxHP)
                {
                    curHP = maxHP;
                }
                if (curHP < 0)
                {
                    curHP = 0.0;
                    int num = (new Random()).Next(1, 10);
                    if (!(num == 9 || num == 10))
                    {
                        this.curHP = this.maxHP;
                    }
                }
                return curHP;
        }
    }
}
