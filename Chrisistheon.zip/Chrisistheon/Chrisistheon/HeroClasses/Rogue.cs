﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chrisistheon
{
    public class Rogue : A_Hero
    {
        public Rogue(double hp, int pwr, int def, int spd) : base("Rogue", hp, pwr, def, spd)
        {

        }

        public override int Attack()
        {
            return -1;
        }
    }
}
