﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chrisistheon
{
    public class Cleric: A_Hero
    {

        public Cleric(double hp, int pwr, int def, int spd) : base("Cleric", hp, pwr, def, spd)
        {

        }

        public override string Attack()
        {
            return "";
        }

    }
}
