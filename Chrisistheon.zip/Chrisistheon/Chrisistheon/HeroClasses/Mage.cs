﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chrisistheon
{
    public class Mage: A_Hero
    {

        public Mage(double hp, int pwr, int def, int spd) : base("Mage", hp, pwr, def, spd)
        {

        }

        public override int Attack()
        {
            return -1;
        }
    }
}
