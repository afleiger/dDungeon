﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Chrisistheon
{
    class NullClass:A_Hero
    {
        public NullClass(string classname, double hp, int pwr, int def, int spd):base("Null",hp,pwr,  def,  spd)
        {
            MessageBox.Show("Class Name:"+classname+"\nSomething went wrong, null class was created. \n Please stop and fix ASAP.");
        }
    }
}
