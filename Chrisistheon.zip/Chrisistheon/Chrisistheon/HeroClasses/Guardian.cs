﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chrisistheon
{
    class Guardian:A_Hero
    {
        public Guardian(double hp, int pwr, int def, int spd) : base("Guardian", hp, pwr, def, spd)
        {

        }

        public override int Attack()
        {
            return -1;
        }
    }
}
