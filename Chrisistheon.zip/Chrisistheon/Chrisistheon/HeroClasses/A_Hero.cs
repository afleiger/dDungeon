﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chrisistheon
{
    public abstract class A_Hero : A_Entity
    {
        public A_Hero(string classname, double hp, int pwr, int def, int spd) : base(classname, hp, pwr, def, spd)
        {
            
        }

        public override int Attack()
        {
            throw new NotImplementedException();
        }

        public void reset()
        {
            this.comDef = 0;
            this.comPwr = 0;
            this.comSpd = 0;
        }

    }
}
