﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chrisistheon
{
    public abstract class A_Hero : A_Entity
    {
        private string weapon;
        private string armor;
        private int curSlots;
        private int maxSlots;
        public A_Hero(string classname, double hp, int pwr, int def, int spd) : base(classname, hp, pwr, def, spd)
        {
            
        }

        public override string Attack()
        {
            throw new NotImplementedException();
        }

        public override double manipulateHealth(double hpChange)
        {

                curHP += hpChange;
                if (curHP > maxHP)
                {
                    curHP = maxHP;
                }
                if (curHP < 0)
                {
                    curHP = 0.0;
                }
                return curHP;
        }

        public void reset()
        {
            this.comDef = 0;
            this.comPwr = 0;
            this.comSpd = 0;
        }

    }
}
