﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chrisistheon
{
    public class Archer : A_Hero
    {

        public Archer(double hp, int pwr, int def, int spd) : base("Archer", hp, pwr, def, spd)
        {

        }

        public override int Attack()
        {
            return -1;
        }


    }
}
