﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chrisistheon
{
    class Simba:A_Hero
    {
        public Simba(double hp, int pwr, int def, int spd) : base("Simba", hp, pwr, def, spd)
        {

        }

        public override string Attack()
        {
            return "";
        }
    }
}
