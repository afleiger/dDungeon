﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chrisistheon
{
    class Elementalist:A_Hero
    {
        public Elementalist(double hp, int pwr, int def, int spd) : base("Elementalist", hp, pwr, def, spd)
        {

        }

        public override string Attack()
        {
            return "";
        }
    }
}
