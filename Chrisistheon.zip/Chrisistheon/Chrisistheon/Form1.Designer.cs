﻿namespace Chrisistheon
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.titleLB = new System.Windows.Forms.Label();
            this.startBT = new System.Windows.Forms.Button();
            this.loadBT = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // titleLB
            // 
            this.titleLB.Image = ((System.Drawing.Image)(resources.GetObject("titleLB.Image")));
            this.titleLB.Location = new System.Drawing.Point(0, 0);
            this.titleLB.Name = "titleLB";
            this.titleLB.Size = new System.Drawing.Size(297, 200);
            this.titleLB.TabIndex = 0;
            // 
            // startBT
            // 
            this.startBT.Location = new System.Drawing.Point(105, 261);
            this.startBT.Name = "startBT";
            this.startBT.Size = new System.Drawing.Size(75, 23);
            this.startBT.TabIndex = 1;
            this.startBT.Text = "Start";
            this.startBT.UseVisualStyleBackColor = true;
            this.startBT.Click += new System.EventHandler(this.startBT_Click);
            // 
            // loadBT
            // 
            this.loadBT.Enabled = false;
            this.loadBT.Location = new System.Drawing.Point(105, 312);
            this.loadBT.Name = "loadBT";
            this.loadBT.Size = new System.Drawing.Size(75, 23);
            this.loadBT.TabIndex = 2;
            this.loadBT.Text = "Load";
            this.loadBT.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(297, 462);
            this.Controls.Add(this.loadBT);
            this.Controls.Add(this.startBT);
            this.Controls.Add(this.titleLB);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label titleLB;
        private System.Windows.Forms.Button startBT;
        private System.Windows.Forms.Button loadBT;
    }
}