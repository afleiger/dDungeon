﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Chrisistheon
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private GuiState _state = new GuiState();
        private Dungeon _dungeon;
        private Party _party = new Party();
        private A_Hero[] choice;

        public MainWindow()
        {
            InitializeComponent();
            this.mapTB.IsReadOnly = true;
            this.interactionTB.IsReadOnly = true;
            this.interactionTB.Text = "Welcome to Chrisistheon!\n";
            /*
             * Potentially think about making the A_Hero list of choices a class variable
             * 
             */
            choice = this.getChoices(3);
            this.partyTB.Text += "1)."+choice[0].ToString() + "\n\n2)." + choice[1].ToString() + "\n\n3)." + choice[2].ToString() + "\n";
            this.interactionTB.Text += "Before we can begin your journey you must decide what class you would like to play as, \n 1). " +choice[0].GetName()+
                "\n 2). "+choice[1].GetName()+" \n 3). "+choice[2].GetName()+" \n "
                + "please select the corresponding button for the class you want to play.\n";
            
            
            
        }

        private A_Hero[] getChoices(int number)
        {
            string[] classes = new string[5];
            classes[0] = "Warrior";
            classes[1] = "Mage";
            classes[2] = "Cleric";
            classes[3] = "Archer";
            classes[4] = "Rogue";

            A_Hero[] choices = new A_Hero[number];
            string[] selection = new string[number];
            int counter = 0;
            while (counter < number)
            {

                int random = (new Random()).Next(0, classes.Length);
                while (!isUnique(classes[random], selection))
                {
                    random = (new Random()).Next(0, classes.Length);
                }
                selection[counter] = classes[random];
                counter++;
            }
            for (int i = 0; i < selection.Length; i++)
            {
                choices[i] = HeroFactory.gernerateHero(selection[i]);
            }
            return choices;
        }

        private static Boolean isUnique(String choice, String[] choices)
        {
            Boolean unique = true;
            for (int i = 0; i < choices.Length; i++)
            {
                if (choices[i] != null && choice.Equals(choices[i]))
                {
                    unique = false;
                }
            }
            return unique;
        }

        #region Movement
        private void upArrow_Click(object sender, RoutedEventArgs e)
        {
            if (_state.State == State.Room)
            {
                _dungeon.moveUp();
                this.mapTB.Text = _dungeon.GetRoomString();
                this.interactionTB.Text = _dungeon.infoString +"\n";
            }    
        }

        private void rightArrow_Click(object sender, RoutedEventArgs e)
        {
            if(_state.State == State.Room)
            {
                _dungeon.moveRight();
                this.mapTB.Text = _dungeon.GetRoomString();
                this.interactionTB.Text = _dungeon.infoString + "\n";
            }
        }

        private void leftArrow_Click(object sender, RoutedEventArgs e)
        {
            if(_state.State == State.Room)
            {
                _dungeon.moveLeft();
                this.mapTB.Text = _dungeon.GetRoomString();
                this.interactionTB.Text = _dungeon.infoString + "\n";
            }
        }

        private void downArrow_Click(object sender, RoutedEventArgs e)
        {
            if(_state.State == State.Room)
            {
                _dungeon.moveDown();
                this.mapTB.Text = _dungeon.GetRoomString();
                this.interactionTB.Text = _dungeon.infoString + "\n";
            }
        }
        #endregion

        #region Buttons
        private void oneBT_Click(object sender, RoutedEventArgs e)
        {
            if (this._state.State == State.Intro)
            {
                this.interactionTB.Text += "You chose option 1\n";
                // Add hero option
                this._party.AddHero(0, this.choice[0]);
                this._state.SetStateToSelectP1();
                choice = getChoices(5);
                this.interactionTB.Text = "Before you begin your journey you must select two people to aid you on your journey. \n";
                this.partyTB.Text = "";
                for (int i=0;i<choice.Length;i++)
                {
                    this.partyTB.Text += (i+1) + ")." + choice[i].ToString()+"\n\n";
                }
                //this.mapTB.Text = _dungeon.GetRoomString();
            }else if (this._state.State == State.SelectP1)
            {
                this.interactionTB.Text += "You chose option 1\n";
                // Add hero option
                this._party.AddHero(1, this.choice[0]);
                this.interactionTB.Text += "Now you must choose the second member\n";
                choice = getChoices(5);
                partyTB.Text = "";
                for (int i = 0; i < choice.Length; i++)
                {
                    this.partyTB.Text += (i + 1) + ")." + choice[i].ToString() + "\n\n";
                }
                this._state.SetStateToSelectP2();
            }else if (this._state.State == State.SelectP2)
            {
                this.interactionTB.Text += "You chose option 1\n";
                // Add hero option
                this._party.AddHero(2, this.choice[0]);
                this._dungeon = new Dungeon();
                this._state.SetStatetoRoom();
                this.mapTB.Text = _dungeon.GetRoomString();
                this.partyTB.Text = _party.ToString();

            }
        }

        private void twoBT_Click(object sender, RoutedEventArgs e)
        {
            if (this._state.State == State.Intro)
            {
                this.interactionTB.Text += "You chose option 2\n";
                this._state.SetStateToSelectP1();
                // Add hero option
                this._party.AddHero(0, this.choice[1]);
                A_Hero[] choices = getChoices(5);
                this.interactionTB.Text = "Before you begin your journey you must select two people to aid you on your journey. \n";
                this.partyTB.Text = "";
                for (int i = 0; i < choices.Length; i++)
                {
                    this.partyTB.Text += (i + 1) + ")." + choices[i].ToString() + "\n\n";
                }
                //this.mapTB.Text = _dungeon.GetRoomString();
            }
            else if (this._state.State == State.SelectP1)
            {
                this.interactionTB.Text += "You chose option 2\n";
                // Add hero option
                this._party.AddHero(1, this.choice[1]);
                this.interactionTB.Text += "Now you must choose the second member\n";
                choice = getChoices(5);
                partyTB.Text = "";
                for (int i = 0; i < choice.Length; i++)
                {
                    this.partyTB.Text += (i + 1) + ")." + choice[i].ToString() + "\n\n";
                }
                this._state.SetStateToSelectP2();
            }
            else if (this._state.State == State.SelectP2)
            {
                this.interactionTB.Text += "You chose option 2\n";
                // Add hero option
                this._party.AddHero(2, this.choice[1]);
                this._dungeon = new Dungeon();
                this._state.SetStatetoRoom();
                this.mapTB.Text = _dungeon.GetRoomString();
                this.partyTB.Text = _party.ToString();

            }
        }

        private void threeBT_Click(object sender, RoutedEventArgs e)
        {
            if (this._state.State == State.Intro)
            {
                this.interactionTB.Text += "You chose option 3\n";
                this._state.SetStateToSelectP1();
                // Add hero option
                this._party.AddHero(0, this.choice[2]);
                choice = getChoices(5);
                this.interactionTB.Text = "Before you begin your journey you must select two people to aid you on your journey. \n";
                this.partyTB.Text = "";
                for (int i = 0; i < choice.Length; i++)
                {
                    this.partyTB.Text += (i + 1) + ")." + choice[i].ToString() + "\n\n";
                }
                //this.mapTB.Text = _dungeon.GetRoomString();
            }
            else if (this._state.State == State.SelectP1)
            {
                this.interactionTB.Text += "You chose option 3\n";
                // Add hero option
                this._party.AddHero(1, this.choice[2]);
                this.interactionTB.Text += "Now you must choose the second member\n";
                choice = getChoices(5);
                partyTB.Text = "";
                for (int i = 0; i < choice.Length; i++)
                {
                    this.partyTB.Text += (i + 1) + ")." + choice[i].ToString() + "\n\n";
                }
                this._state.SetStateToSelectP2();
            }
            else if (this._state.State == State.SelectP2)
            {
                this.interactionTB.Text += "You chose option 3\n";
                // Add hero option
                this._party.AddHero(2, this.choice[2]);
                this._dungeon = new Dungeon();
                this._state.SetStatetoRoom();
                this.mapTB.Text = _dungeon.GetRoomString();
                this.partyTB.Text = _party.ToString();

            }
        }

        private void fourBT_Click(object sender, RoutedEventArgs e)
        {
            if (this._state.State == State.SelectP1)
            {
                this.interactionTB.Text += "You chose option 4\n";
                // Add hero option
                this._party.AddHero(1, this.choice[3]);
                this.interactionTB.Text += "Now you must choose the second member\n";
                A_Hero[] choices = getChoices(5);
                partyTB.Text = "";
                for (int i = 0; i < choices.Length; i++)
                {
                    this.partyTB.Text += (i + 1) + ")." + choices[i].ToString() + "\n\n";
                }
                this._state.SetStateToSelectP2();
            }
            else if (this._state.State == State.SelectP2)
            {
                this.interactionTB.Text += "You chose option 4\n";
                // Add hero option
                this._party.AddHero(2, this.choice[3]);
                this._dungeon = new Dungeon();
                this._state.SetStatetoRoom();
                this.mapTB.Text = _dungeon.GetRoomString();
                this.partyTB.Text = _party.ToString();

            }
        }

        private void fiveBT_Click(object sender, RoutedEventArgs e)
        {
            if (this._state.State == State.SelectP1)
            {
                this.interactionTB.Text += "You chose option 5\n";
                // Add hero option
                this._party.AddHero(1, this.choice[4]);
                this.interactionTB.Text += "Now you must choose the second member\n";
                A_Hero[] choices = getChoices(5);
                partyTB.Text = "";
                for (int i = 0; i < choices.Length; i++)
                {
                    this.partyTB.Text += (i + 1) + ")." + choices[i].ToString() + "\n\n";
                }
                this._state.SetStateToSelectP2();
            }
            else if (this._state.State == State.SelectP2)
            {
                this.interactionTB.Text += "You chose option 5\n";
                // Add hero option
                this._party.AddHero(2, this.choice[4]);
                this._dungeon = new Dungeon();
                this._state.SetStatetoRoom();
                this.mapTB.Text = _dungeon.GetRoomString();
                this.partyTB.Text = _party.ToString();
                
            }
        }
        #endregion
    }
}
