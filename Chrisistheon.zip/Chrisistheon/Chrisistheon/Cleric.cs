﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chrisistheon
{
    public class Cleric: A_Hero
    {

    public Cleric()
    {
        
    }

    public override string GetName()
    {
        return "Cleric";
    }

    public override string ToString()
    {
        return "Cleric \n" + base.ToString();
    }
}
}
