﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chrisistheon
{
    public enum State
    {
        Intro,
        SelectP1,
        SelectP2,
        Room,
        Battle
    };

    public class GuiState
    {
        private State _state = State.Intro;

        public GuiState(){}

        public State State
        {
            get { return _state; }
        }

        public void SetStatetoRoom()
        {
            this._state = State.Room;
        }

        public void SetStatetoBattle()
        {
            this._state = State.Battle;
        }

        public void SetStatetoIntro()
        {
            this._state = State.Intro;
        }

        public void SetStateToSelectP1()
        {
            this._state = State.SelectP1;
        }

        public void SetStateToSelectP2()
        {
            this._state = State.SelectP2;
        }

    }
}
