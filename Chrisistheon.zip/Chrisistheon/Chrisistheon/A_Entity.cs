﻿using System;

namespace Chrisistheon
{
    public abstract class A_Entity
    {
        protected string className;
        protected double maxHP;
        protected double curHP;
        protected int pwr;
        protected int def;
        protected int spd;
        protected int comPwr;
        protected int comDef;
        protected int comSpd;

        public A_Entity(string className, double hp, int pwr, int def, int spd)
        {
            this.className = className;
            this.maxHP = hp;
            this.curHP = hp;
            this.pwr = pwr;
            this.def = def;
            this.spd = spd;
            this.comPwr = 0;
            this.comDef = 0;
            this.comSpd = 0;
        }

        #region Gets
        public string ClassName
        {
            get
            {
                return className;
            }
        }
        public double CurHp
        {
            get
            {
                return curHP;
            }
        }

        public double MaxHP
        {
            get { return maxHP; }
        }

        public int Pwr
        {
            get
            {
                return pwr;
            }
        }

        public int Def
        {
            get
            {
                return def;
            }
        }
        public int Spd
        {
            get
            {
                return spd;
            }
        }
        #endregion

        public abstract double manipulateHealth(double hpChange);
        
        public abstract string Attack();

        public override string ToString()
        {
            return className + ": " + maxHP + ", " + pwr + ", " + def + ", " + spd;
        }


    }
}