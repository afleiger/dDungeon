﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chrisistheon
{
    public class Rogue : A_Hero
    {

    public Rogue()
    {
       
    }
    public override string GetName()
    {
        return "Rogue";
    }
    public override string ToString()
    {
        return "Rogue \n" + base.ToString();
    }
}
}
