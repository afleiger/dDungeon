﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chrisistheon
{
    public class Warrior :A_Hero
    {

    public Warrior()
    {

    }

    public override string GetName()
    {
        return "Warrior";
    }
    public override string ToString()
    {
        return "Warrior \n" + base.ToString();
    }
}

}
