﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chrisistheon
{
    public class HeroFactory
    {
        public static A_Hero gernerateHero(string entity)
        {
            if (entity.Equals("Warrior"))
                return new Warrior();
            if (entity.Equals("Mage"))
                return new Mage();
            if (entity.Equals("Cleric"))
                return new Cleric();
            if (entity.Equals("Rogue"))
                return new Rogue();
            if (entity.Equals("Archer"))
                return new Archer();
            return null;
        }

    }
}
