﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChrisistheonGUI
{
    public class SuperSonic : A_Ability
    {
        public SuperSonic()
            : base("Sonic", "Emits a sonic wave, confusing the target", 0, 2)
        {

        }

        public override string use(A_Entity self, List<A_Entity> targets)
        {
            int attackRoll;
            int toHit;
    
                attackRoll = Dungeon.gRandom.Next(1, 101);
                toHit = 80 + (int)(self.speed - targets[0].speed);
                if (attackRoll > toHit)
                {
                    return "\n-MISS-" + self.charString + " emits a sonar wave in the oppisite direction from" + targets[0].charString;
                }
                else
                {
                   
                    targets[0].speed -= 5;
                    return "\n-HIT-" + self.charString + " has located " + targets[0].charString + " with the emit sonar wave, and "+ targets[0].charString+"speed has been reduced";
                }
        }
    }
}