﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChrisistheonGUI
{
    public class FeralDog : A_Monster
    {

        public FeralDog()
            : base("Feral Dog", 223, 11, 15, 11, "A wild, enraged dog", 0)
        {
            AddAbility(new BiteAttack());
            AddAbility(new ClawAttack());

        }

        public override string TakeTurn(Party heroP, MonsterParty monsterP)
        {
            List<A_Entity> targs = new List<A_Entity>();

            int rand = Dungeon.gRandom.Next(0, 2);
            if (rand == 1)
            {
                targs.Add(heroP.RandomTarget);
                return AbilityList[1].use(this, targs);
            }

            targs.Add(heroP.RandomTarget);
            return AbilityList[0].use(this, targs);
        }
    }
}
