﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChrisistheonGUI
{
    public class Rat : A_Monster
    {

        public Rat()
            : base("Rat", 30, 7, 5, 15, "A wild, enraged dog", 0)
        {
            AddAbility(new BiteAttack());
        }

        public override string TakeTurn(Party heroP, MonsterParty monsterP)
        {
            List<A_Entity> targs = new List<A_Entity>();
            targs.Add(heroP.RandomTarget);
            return AbilityList[0].use(this, targs);
        }
    }
}
